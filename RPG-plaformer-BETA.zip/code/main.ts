import kaboom from "kaboom"
import "kaboom/global"
let test = 500
let angle = 20
let reason = 'You fell into the void'
kaboom({
  clearColor: [25, 25, 112],
    width: 1280,
    height: 720
})
let side = "right"

loadSpriteAtlas('Sprites/tileset.png', {
    'platform-left': { x: 82, y: 64, width: 16,
        height: 8
    },
    'platform-middle': {
        x: 112,
        y: 64,
        width: 16,
        height: 8
    },
    'platform-right': {
        x: 142,
        y: 64,
        width: 16,
        height: 8
    },
    'smaller-tree': {
        x: 0,
        y: 80,
        width: 60,
        height: 65
    },
    'bigger-tree': {
        x: 170,
        y: 10,
        width: 115,
        height: 200
    },
    'ground': {
        x: 80,
        y: 144,
        width: 16,
        height: 16
    },
    'ground-deep': {
        x: 0,
        y: 144,
        width: 16,
        height: 16
    }
})
loadSpriteAtlas('Sprites/demon.png', {
    'demon': { x: 100, y: 54, width: 40,
        height: 40
    }
})

loadSprite('background-0', 'Sprites/background_0.png')
loadSprite('background-1', 'Sprites/background_1.png')
loadSprite('background-2', 'Sprites/background_2.png')
loadSprite('enemy', 'Sprites/enemy.png')
loadSprite('portal', 'Sprites/portal.png')
loadSprite('made', 'Sprites/made.png')
loadSprite('square', 'Sprites/square.png')
loadSprite('redSquare', 'Sprites/rSquare.png')
loadSprite('idle-sprite', 'Sprites/Idle.png', {
    sliceX: 8,
    sliceY: 1,
    anims: { 'idle-anim': { from: 0, to: 7, loop: true }}
})
loadSprite('run-sprite', 'Sprites/Run.png', {
    sliceX: 8,
    sliceY: 1,
    anims: { 'run-anim': { from: 0, to: 7, loop: true }}
})

loadSprite('jump-sprite', 'Sprites/Jump.png', {
    sliceX: 2,
    sliceY: 1,
    anims: { 'jump-anim': { from: 0, to: 1, loop: true }}
})

loadSprite('fall-sprite', 'Sprites/Fall.png', {
    sliceX: 2,
    sliceY: 1,
    anims: { 'fall-anim' : { from: 0, to: 1, loop: true }}
})

setGravity(1000)

add([
    sprite('background-0'),
    fixed(), 
    scale(4)
])

add([
    sprite('background-0'),
    fixed(),
    pos(1000, 0),
    scale(4),
]).flipX = true

add([
    sprite('background-1'),
    fixed(),
    scale(4)
])

add([
    sprite('background-1'),
    fixed(),
    pos(1000, 0),
    scale(4),
]).flipX = true

add([
    sprite('background-2'),
    fixed(),
    scale(4)
])








add([
    sprite('background-2'),
    fixed(),
    pos(1000, 0),
    scale(4),
]).flipX = true

const tree = add([
    sprite('smaller-tree'),
    scale(4),
    pos(300, 190)
])
const tree1 = add([
    sprite('smaller-tree'),
    scale(4),
    pos(2200, 390)
])
const tree2 = add([
    sprite('smaller-tree'),
    scale(4),
    pos(2500, 390)
]).flipX = true



const map = addLevel([
  
'5                                                       335',
'5                                                       445',
'5333                                                    445',
'5444                                      012           445',
'5444                                                    445',
'5444                                          012       445',
'5444                                                    445',
'5444333333                                         012  445',
'5444444444                                              445',
'5444444444                 012                          435',
'54444444443333333333333           3333333333333333333333445',
'54444444444444444444444           4444444444444444444444445',
'54444444444444444444444           4444444444444444444444445',
'54444444444444444444444           4444444444444444444444445',
'54444444444444444444444           4444444444444444444444445', '54444444444444444444444           4444444444444444444444445'
], {
    tileWidth: 16,
    tileHeight: 16,
    tiles: {
        0: () => [
            sprite('platform-left'),
            area(),
            body({isStatic: true})
        ],
        1: () => [
            sprite('platform-middle'),
            area(),
            body({isStatic: true})
        ],
        2: () => [
            sprite('platform-right'),
            area(),
            body({isStatic: true})
        ],
        3: () => [
            sprite('ground'),
            area(),
            body({isStatic: true})
        ],
        4: () => [
            sprite('ground-deep'),
            area(),
            body({isStatic: true})
        ],
        5: () => [
            rect(16, 16),
            opacity(0),
            area(),
            body({isStatic: true})
        ],
        6: () => [
            sprite('square'),
            area(),
            body({isStatic: true})
        ],
       7: () => [
          sprite('redSquare'),
          area(),
          body({isStatic: true})
      ]
    }
})

// text
add([
    pos(700, 250),
    text("→", {
        size: 150, // 48 pixels tall
        width: 320, // it'll wrap to next line when width exceeds this value
        font: "sans-serif", // specify any font you loaded or browser built-in
    }),
])

const made = add([
    sprite('made'),
    scale(1),
    pos(100,500),
]);

map.use(scale(4))

const biggerTree = add([
    sprite('bigger-tree'),
    scale(4),
    pos(900,104),
   "bigger-tree",
])
const biggerTree1 = add([
    sprite('bigger-tree'),
    scale(4),
    pos(3000,104)
])

const player = add([
    sprite('idle-sprite'),
    scale(2),
    area({shape: new Rect(vec2(0), 32, 32), offset: vec2(0,32)}),
    anchor('center'),
    body(),
    pos(500,400),
    {
        speed: 500,
        previousHeight: null,
        heightDelta: 0,
        direction: 'right'
    }
])

const redSquare = add([
    sprite('demon'),
    pos(3000, 570),
    area(),
    'demon',
])

redSquare.width = 50;
redSquare.height = 50;
player.onCollide('demon', () => {
  reason = 'The demon slayed you!'
  go('after')

})
const portal = add([
    sprite('portal'),
    pos(2750, 80),
    area(),
    body({isStatic: true}),
    'portal',
])
player.onCollide('portal', () => {
  go('lvl2')
  
})



player.play('idle-anim')

onKeyDown('right', () => {

    if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
        player.use(sprite('run-sprite'))
        player.play('run-anim')
    }

    if (player.direction !== 'right') player.direction = 'right'

    player.move(player.speed, 0)
})

onKeyRelease('right', () => {
    player.use(sprite('idle-sprite'))
    player.play('idle-anim')
})

onKeyDown('left', () => {
    if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
        player.use(sprite('run-sprite'))
        player.play('run-anim')
    }

    if (player.direction !== 'left') player.direction = 'left'

    player.move(-player.speed, 0)
})

onKeyRelease('left', () => {
    player.use(sprite('idle-sprite'))
    player.play('idle-anim')
})

onKeyPress('up', () => {
    if (player.isGrounded()) {
        player.jump()
    }
})
onKeyPress('2', () => {
  go("lvl2");
})
onKeyPress('3', () => {
  go("lvl3");
})
// how zoomed in
camScale(1)




onUpdate(() => {
  redSquare.width = 65;
  redSquare.height = 75;
  portal.width = 100;
  portal.height = 100;
  portal.flipX = true;
  
  if (player.pos.x > redSquare.pos.x){
    redSquare.pos.x += 15
    redSquare.flipX = true
    
  }else{
    if (redSquare.pos.x > 2165){
      redSquare.pos.x -= 15
      redSquare.flipX = false
    }
    
  }
  console.log(redSquare.pos.x)
  if (player.pos.y > 1000) {
    go("after");
  }
 
    if (player.previousHeight) {
        player.heightDelta = player.previousHeight - player.pos.y
    }

    player.previousHeight = player.pos.y

    const cameraLeftBound = 550
    const cameraRightBound = 3000
    const cameraVerticalOffset = player.pos.y - 100

    if (cameraLeftBound > player.pos.x) {
        camPos(cameraLeftBound, cameraVerticalOffset + 200)
    } else if (cameraRightBound < player.pos.x) {
        camPos(cameraRightBound, cameraVerticalOffset + 200)
    } else {
        camPos(player.pos.x, cameraVerticalOffset + 200)
    }

    if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
        player.use(sprite('idle-sprite'))
        player.play('idle-anim')
    }

    if (player.curAnim() !== 'jump-anim' && !player.isGrounded() && player.heightDelta > 0) {
        player.use(sprite('jump-sprite'))
        player.play('jump-anim')
    }

    if (player.curAnim() !== 'fall-anim' && !player.isGrounded() && player.heightDelta < 0) {
        player.use(sprite('fall-sprite'))
        player.play('fall-anim')
    }

    if (player.direction === 'left') {
        player.flipX = true
    } else {
        player.flipX = false
    }
})




scene("after", (score) => {



  //background

  add([
      sprite('background-0'),
      fixed(), 
      scale(4)
  ])

  add([
      sprite('background-0'),
      fixed(),
      pos(1000, 0),
      scale(4),
  ]).flipX = true

  add([
      sprite('background-1'),
      fixed(),
      scale(4)
  ])

  add([
      sprite('background-1'),
      fixed(),
      pos(1000, 0),
      scale(4),
  ]).flipX = true

  add([
      sprite('background-2'),
      fixed(),
      scale(4)
  ])
  add([
    text(reason),
    pos(width() / 2, height() / 2 + 10),
    scale(2),
    anchor("center"),
  ]);

});

scene("lvl2", (score) => {



  //background

  add([
      sprite('background-0'),
      fixed(), 
      scale(4)
  ])

  add([
      sprite('background-0'),
      fixed(),
      pos(1000, 0),
      scale(4),
  ]).flipX = true

  add([
      sprite('background-1'),
      fixed(),
      scale(4)
  ])

  add([
      sprite('background-1'),
      fixed(),
      pos(1000, 0),
      scale(4),
  ]).flipX = true

  add([
      sprite('background-2'),
      fixed(),
      scale(4)
  ])
  const block = add([
      sprite('ground'),
      pos(1000,800),
      area(),
      scale(4),
      body({isStatic: true})
  ])
  const block1 = add([
      sprite('ground'),
      pos(1400,800),
      area(),
      scale(4),
      body({isStatic: true})
  ])
  const block2 = add([
      sprite('ground'),
      pos(1800,800),
      area(),
      scale(4),
      body({isStatic: true})
  ])
  const tree = add([
      sprite('smaller-tree'),
      scale(4),
      pos(300, 450)
  ])
  const tree1 = add([
      sprite('bigger-tree'),
      scale(4),
      pos(3000, 240)
  ])
  const redSquare = add([
      sprite('enemy'),
      pos(3000,700),
      area(),
      body(),
      'enemy',
  ])
  const portal = add([
      sprite('portal'),
      pos(3000, 150),
      area(),
      body({isStatic: true}),
      'portal',
  ])

  
  //level 2
  const map = addLevel([
  '5                                                       335',
  '5                                                       445',
  '5                                                       445',
  '5                                                       445',
  '5                                             012       445',
  '5                                                       445',
  '5333                                                    445',
  '5444                                    011112          445',
  '5444                                                    445',
  '5444                                          012       445',
  '5444                                                    445',
  '5444333333                                              445',
  '5444444444                        012   3333333333333333445',
  '5444444444                              4444444444444444435',
  '5444444444                              4444444444444444445',
  '5444444444                              4444444444444444445',
  '5444444444                              4444444444444444445',
  '5444444444                              4444444444444444445',
  '5444444444                              4444444444444444445', 
  '5444444444                              4444444444444444445'
  ], {
      tileWidth: 16,
      tileHeight: 16,
      tiles: {
          0: () => [
              sprite('platform-left'),
              area(),
              body({isStatic: true})
          ],
          1: () => [
              sprite('platform-middle'),
              area(),
              body({isStatic: true})
          ],
          2: () => [
              sprite('platform-right'),
              area(),
              body({isStatic: true})
          ],
          3: () => [
              sprite('ground'),
              area(),
              body({isStatic: true})
          ],
          4: () => [
              sprite('ground-deep'),
              area(),
              body({isStatic: true})
          ],
          5: () => [
              rect(16, 16),
              opacity(0),
              area(),
              body({isStatic: true})
          ],
          6: () => [
              sprite('square'),
              area(),
              body({isStatic: true})
          ],
         7: () => [
            sprite('redSquare'),
            area(),
            body({isStatic: true})
        ]
      }
  })
  camScale(1)
  const player = add([
      sprite('idle-sprite'),
      scale(2),
      area({shape: new Rect(vec2(0), 32, 32), offset: vec2(0,32)}),
      anchor('center'),
      body(),
      pos(500,600),
      {
          speed: 500,
          previousHeight: null,
          heightDelta: 0,
          direction: 'right'
      }
  ])
  add([
      pos(200, 800),
      text("Level 2", {
          size: 100, // 48 pixels tall
          width: 500, // it'll wrap to next line when width exceeds this value
          font: "sans-serif", // specify any font you loaded or browser built-in
      }),
  ])
  player.onCollide('portal', () => {
    //reason = 'You win!'
    go('lvl3')

  })
  player.onCollide('enemy', () => {
    reason = 'The amphibian slayed you!'
    go('after')

  })
  player.play('idle-anim')

  onKeyDown('right', () => {

      if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
          player.use(sprite('run-sprite'))
          player.play('run-anim')
      }

      if (player.direction !== 'right') player.direction = 'right'

      player.move(player.speed, 0)
  })

  onKeyRelease('right', () => {
      player.use(sprite('idle-sprite'))
      player.play('idle-anim')
  })

  onKeyDown('left', () => {
      if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
          player.use(sprite('run-sprite'))
          player.play('run-anim')
      }

      if (player.direction !== 'left') player.direction = 'left'

      player.move(-player.speed, 0)
  })

  onKeyRelease('left', () => {
      player.use(sprite('idle-sprite'))
      player.play('idle-anim')
  })

  onKeyPress('up', () => {
      if (player.isGrounded()) {
          player.jump()
      }
  })
 
  map.use(scale(4))
  
  onUpdate(() => {
    
    if (player.pos.y > 1000) {
      reason = 'You fell into the void'
      go("after");
      
    }
    portal.width = 100;
    portal.height = 100;
  redSquare.width = 50;
  redSquare.height = 75;
  block.width = 30;
  block.height = 30;
  block1.width = 30;
  block1.height = 30;
  block2.width = 30;
  block2.height = 30;
     
    if (player.pos.x > redSquare.pos.x){
      redSquare.pos.x += 16
      redSquare.flipX = true
      if (redSquare.isGrounded()) {
   
      redSquare.jump(300);
      }else{
     
        redSquare.pos.y += 1;
      }
    }else{
      if (redSquare.pos.x > 2550){
        redSquare.pos.x -= 16
        redSquare.flipX = false
        if (redSquare.isGrounded()) {
      
        redSquare.jump(300);
        }else{
          
          redSquare.pos.y += 1;
        }
      }

    }
  block.angle = angle
  block1.angle = angle
  block2.angle = angle
    
    angle +=  3
      if (player.previousHeight) {
          player.heightDelta = player.previousHeight - player.pos.y
      }

      player.previousHeight = player.pos.y

      const cameraLeftBound = 550
      const cameraRightBound = 3000
      const cameraVerticalOffset = player.pos.y - 100

      if (cameraLeftBound > player.pos.x) {
          camPos(cameraLeftBound, cameraVerticalOffset +200)
      } else if (cameraRightBound < player.pos.x) {
          camPos(cameraRightBound, cameraVerticalOffset + 200)
      } else {
          camPos(player.pos.x, cameraVerticalOffset + 200)
      }

      if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
          player.use(sprite('idle-sprite'))
          player.play('idle-anim')
      }

      if (player.curAnim() !== 'jump-anim' && !player.isGrounded() && player.heightDelta > 0) {
          player.use(sprite('jump-sprite'))
          player.play('jump-anim')
      }

      if (player.curAnim() !== 'fall-anim' && !player.isGrounded() && player.heightDelta < 0) {
          player.use(sprite('fall-sprite'))
          player.play('fall-anim')
      }

      if (player.direction === 'left') {
          player.flipX = true
      } else {
          player.flipX = false
      }
  })
});
scene("lvl3", (score) => {
// load background
  add([
      sprite('background-0'),
      fixed(),
   
      scale(5),
  ]).flipX = true

  add([
      sprite('background-1'),
      fixed(),
      scale(5)
  ])

  add([
      sprite('background-1'),
      fixed(),
      scale(5),
  ]).flipX = true

  add([
      sprite('background-2'),
      fixed(),
      scale(5)
  ])
  const tree = add([
      sprite('smaller-tree'),
      scale(4),
      pos(300, 1025)
  ])
  const platformW = add([
      rect(200, 30),
      pos(1300,1200),
      area(),
      body({isStatic: true}),
      "platformW"
  ])
  const platformW1 = add([
      rect(180, 27),
      pos(2100,900),
      area(),
      body({isStatic: true}),
      "platformW1"
  ])
  const platformW2 = add([
      rect(162, 24),
      pos(2500,750),
      area(),
      body({isStatic: true}),
      "platformW2"
  ])
  const platformW3 = add([
      rect(130, 24),
      pos(2900,600),
      area(),
      body({isStatic: true}),
      "platformW3"
  ])
  const platformW4 = add([
      rect(80, 17),
      pos(2100,300),
      area(),
      body({isStatic: true}),
      "platformW4"
  ])
  const platformW5 = add([
      rect(60, 15),
      pos(1700,150),
      area(),
      body({isStatic: true}),
      "platformW5"
  ])
  const platformW6 = add([
      rect(40, 20),
      pos(1300,0),
      area(),
      body({isStatic: true}),
      "platformW6"
  ])


  //level 3
  const map = addLevel([
  '5                                                       335',
  '5        0111112                                        335',
  '5                                                       335',
  '5                                                       335',
  '5                                                       335',
  '5                                                       335',
  '5                                                       335',
  '5                                     012               335',
  '5                                                       335',
  '5                                                       335',
  '5                                                       445',
  '5                                                       445',
  '5                                                       445',
  '5                                                       445',
  '5                                                       445',
  '5333                                                    445',
  '5444                      012                           445',
  '5444                                                    445',
  '5444                                                    445',
  '5444                                                    445',
  '5444333333    012                                       445',
  '5444444444                                              445',
  '5444444444                                              445',
  '5444444444                                              445',
  '5444444444                                              445',
  '5444444444                                              445',
  '5444444444                                              445',
  '5444444444                                              445', 
  '5444444444                                              445'
  ], {
      tileWidth: 16,
      tileHeight: 16,
      tiles: {
          0: () => [
              sprite('platform-left'),
              area(),
              body({isStatic: true})
          ],
          1: () => [
              sprite('platform-middle'),
              area(),
              body({isStatic: true})
          ],
          2: () => [
              sprite('platform-right'),
              area(),
              body({isStatic: true})
          ],
          3: () => [
              sprite('ground'),
              area(),
              body({isStatic: true})
          ],
          4: () => [
              sprite('ground-deep'),
              area(),
              body({isStatic: true})
          ],
          5: () => [
              rect(16, 16),
              opacity(0),
              area(),
              body({isStatic: true})
          ],
          6: () => [
              sprite('square'),
              area(),
              body({isStatic: true})
          ],
         7: () => [
            sprite('redSquare'),
            area(),
            body({isStatic: true})
        ]
      }
  })
  camScale(1)
  const player = add([
      sprite('idle-sprite'),
      scale(2),
      area({shape: new Rect(vec2(0), 32, 32), offset: vec2(0,32)}),
      anchor('center'),
      body(),
      pos(500,1000),
      {
          speed: 500,
          previousHeight: null,
          heightDelta: 0,
          direction: 'right'
      }
  ])
  const portal = add([
      sprite('portal'),
      pos(550, -30),
      area(),
      body({isStatic: true}),
      'portal',
  ])

  player.onCollide('platformW', () => {
    setTimeout(()=>{ platformW.destroy()}, 500);
   

  })
  player.onCollide('platformW1', () => {
    setTimeout(()=>{ platformW1.destroy()}, 500);


  })
  player.onCollide('platformW2', () => {
    setTimeout(()=>{ platformW2.destroy()}, 500);


  })
  player.onCollide('platformW3', () => {
    setTimeout(()=>{ platformW3.destroy()}, 500);


  })
  player.onCollide('platformW4', () => {
    setTimeout(()=>{ platformW4.destroy()}, 500);


  })
  player.onCollide('platformW5', () => {
    setTimeout(()=>{ platformW5.destroy()}, 500);


  })
  player.onCollide('platformW6', () => {
    setTimeout(()=>{ platformW6.destroy()}, 500);


  })
  map.use(scale(4))
  add([
      pos(200, 1350),
      text("Level 3", {
          size: 100, // 48 pixels tall
          width: 500, // it'll wrap to next line when width exceeds this value
          font: "sans-serif", // specify any font you loaded or browser built-in
      }),
  ])
  player.play('idle-anim')

  onKeyDown('right', () => {

      if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
          player.use(sprite('run-sprite'))
          player.play('run-anim')
      }

      if (player.direction !== 'right') player.direction = 'right'

      player.move(player.speed, 0)
  })

  onKeyRelease('right', () => {
      player.use(sprite('idle-sprite'))
      player.play('idle-anim')
  })

  onKeyDown('left', () => {
      if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
          player.use(sprite('run-sprite'))
          player.play('run-anim')
      }

      if (player.direction !== 'left') player.direction = 'left'

      player.move(-player.speed, 0)
  })

  onKeyRelease('left', () => {
      player.use(sprite('idle-sprite'))
      player.play('idle-anim')
  })

  onKeyPress('up', () => {
      if (player.isGrounded()) {
          player.jump()
      }
  })
  onKeyPress('2', () => {
    go("lvl2");
  })
  onKeyPress('3', () => {
    go("lvl3");
  })
  player.onCollide('portal', () => {
    reason = 'You win!'
    go('after')

  })

   onUpdate(() => {
     portal.width = 100;
     portal.height = 100;
    portal.flipX = true;
     if (player.pos.y > 2000) {
       reason = 'You fell into the void'
       go("after");

     }
   

       if (player.previousHeight) {
         player.heightDelta = player.previousHeight - player.pos.y
     }

     player.previousHeight = player.pos.y
     const cameraLeftBound = 550
     const cameraRightBound = 3000
     const cameraVerticalOffset = player.pos.y - 100

     if (cameraLeftBound > player.pos.x) {
         camPos(cameraLeftBound, cameraVerticalOffset +200)
     } else if (cameraRightBound < player.pos.x) {
         camPos(cameraRightBound, cameraVerticalOffset + 200)
     } else {
         camPos(player.pos.x, cameraVerticalOffset + 200)
     }
     if (player.curAnim() !== 'run-anim' && player.isGrounded()) {
         player.use(sprite('idle-sprite'))
         player.play('idle-anim')
     }

     if (player.curAnim() !== 'jump-anim' && !player.isGrounded() && player.heightDelta > 0) {
         player.use(sprite('jump-sprite'))
         player.play('jump-anim')
     }

     if (player.curAnim() !== 'fall-anim' && !player.isGrounded() && player.heightDelta < 0) {
         player.use(sprite('fall-sprite'))
         player.play('fall-anim')
     }

     if (player.direction === 'left') {
         player.flipX = true
     } else {
         player.flipX = false
     }

     
   })
});